/**
 * Created by pi on 9/20/16.
 */



$(document).ready(function() {

    $('#notify').click(function () {

        if($('.Dropdown3').show()) {
            $('.Dropdown3').hide();
            $('#Message').removeClass('active');
        }
        $('#notify').toggleClass('active');

        $('.Dropdown2').toggle();


    });

    $('#Message').click(function () {
        if($('.Dropdown2').show()) {
            $('.Dropdown2').hide();
            $('#notify').removeClass('active');
        }
        $('#Message').toggleClass('active');

        $('.Dropdown3').toggle();


    });
    var stop=function (e) {e.stopPropagation();};

    $('.Dropdown3 ul').click(stop);
    $('.Dropdown2 ul').click(stop);
    $('.Noti-header').click(stop);
    $('.Noti-footer').click(stop);

    var mousedwn=false;

$('#chat-future').mousedown(function (e){

    mousedwn=true;


    }

);

    $(document).mousemove(function (e) {

        if(mousedwn) {

            $('#chat-future').animate({
                'margin-left': e.pageX - 25 + 'px',
                'margin-top': e.pageY - 25 + 'px'


            }, "fast");
        }
});



});