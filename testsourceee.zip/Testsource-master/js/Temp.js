/**
 * Created by pi on 9/25/16.
 */

//arrays
var number = [1,2,3,4,5];
//at last
number.push(1,2,33)

number[number.length]=1;

//at front
numbers.unshift(2,2,1);

// remove from last
number.pop();

//remove first
number.shift();

// add two array
araay1.concat(array2);

// index of
array2.indexOf("element");

// print element with sperator array
printdata(array1.join(', '));

var obj={
    name: 'dfad',
    country: 'India',
    skill: ['asdas','asdas']
};

//accessing element

println(obj.name);
console.log(obj.name,' ',obj.country);

// for each key

for (key in obj){

    println(obj[key]);

}





//hide elememt
jQuery(".warning").hide();

jQuery=$

//show
jQuery(".class").show();
jQuery(".class").show("slow");

jQuery(".warning").hide().show("slow");


$(".class").append("html");

$("Element").click(function(){

    //code
    $(this).next().remove();
    $(this).prev().remove();

});





//set attr
$(this).attr("href");

//add attr
$(this).attr("src",imglocation);

$option.val("sdfdsf"); //<option value="sdfdsf">

$select.val(); //cureent selection otion value;

//Browser Event
$("Element").click(function(event){

    event.preventdefault();

});





$.each({}); // for each of element


.hasclass --> attr();

$select.prop("Selected",true)

//add class

$Element.addclass("cname");

//remove class

$Element.removeclass("cname");


// get css property

$element.css("Bakground-color");







